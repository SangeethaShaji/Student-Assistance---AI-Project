const express = require("express");
const cors = require("cors");
const OpenAI = require("openai");

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json()); // Middleware to parse JSON bodies

app.post("/answerQuestion", async (req, res) => {
  const question = req.body.question;

  const prompt = `Student question: ${question}\nAI response:`;

  const messages = [
    {
      role: "user",
      content: prompt,
    },
  ];

  try {
    const response = await fetchOpenAICompletion(messages);
    res.json({ answer: response });
  } catch (error) {
    res.status(500).json({ error: "Error fetching OpenAI completion" });
  }
});

async function fetchOpenAICompletion(messages) {
  const OPENAI_API_KEY = "sk-proj-A6S2sEYaNGH7pTyhZ7pUT3BlbkFJpc5XVnyMSEfgWoE7aOB1";
  const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
//   const aiModel = "gpt-3.5-turbo";
  const aiModel = "gpt-4-1106-preview" ;// Use a model you have access to

  try {
    const completion = await openai.chat.completions.create({
      model: aiModel,
      messages: messages,
    });

    return completion.choices[0].message.content;
  } catch (error) {
    console.error("Error fetching OpenAI completion:", error);
    throw error;
  }
}

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
